# Bangla Toon Studio — 5 Original Child Character Sheets

Five **new** Bangladeshi-inspired child characters (not child versions of the previous cast):

| ID | Name | Age | Gender | Role |
|---|---|---:|---|---|
| child_nabil | নাবিল (Nabil) | 10 | Male | Explorer |
| child_rayan | রায়ান (Rayan) | 11 | Male | Inventor |
| child_fahim | ফাহিম (Fahim) | 9 | Male | Village friend |
| child_anika | অনিকা (Anika) | 10 | Female | Science enthusiast |
| child_maliha | মালিহা (Maliha) | 8 | Female | Nature lover |

Each character folder contains `character_sheet.png` and `character.json`. Nabil also has a detailed high-resolution variant. `all_characters_reference.png` shows the whole cast side by side.

Character sheets have turnaround poses, facial expressions, illustrated mouth shape references, action-pose references, and palette cues. The drawings are **concept sheets**, not animation-ready transparent layered rigs; use them to create separate and aligned head/body/eye/mouth layers. Exact lip-sync shape placement and side-view anatomical consistency should be manually checked.

## Source inspiration (no third-party images included)

- https://tourismboard.gov.bd/ (Bangladesh tourism handbook, traditional attire references)
- https://www.observerbd.com/news/130489 (Bangladeshi children's clothing)
- https://www.behance.net/gallery/92081567/Ekam-Water-Conservation-Character-Background-Design (character sheet layout reference)

All included illustrations are newly AI-generated original character concepts rather than copied reference images.
